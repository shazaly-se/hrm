<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PassportAuthController;
use App\Http\Controllers\PostController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\Auth\PermissionController;
use API\RoleController;
use API\CompanyController;
use API\BranchController;
use API\CustomerController;
use API\BranchUsersController;
use API\TaskController;
use API\LeadStatusController;
use API\LifecycleStageController;
use API\ContactOwnersController;
use API\ContactController;
use API\TeamController;
use API\TeamMemberController;
use API\CallController;
use API\DealController;
use API\ContactDealController;
use API\PropertyOwnersController;
use API\PropertyController;
use API\TenantController;
use API\TenancyContractController;
use API\CommissionsController;
use API\PermissionsController;
use API\RolesPermissionsController;
use API\EmployeesController;
use API\AttendanceController;
use API\PunchingController;
use API\LeaveController;
use API\BankDetailsController;
use API\TransferAmountController;
use API\InvoiceController;
use API\UnitController;
use API\TaxesController;
use API\CategoriesController;
use API\ModulesController;
use API\CustomFieldTypesController;
use API\CustomFieldController;
use API\SettingsBusinesController;
use API\ForgotPasswordController;
use API\ResetPasswordController;
use API\ProjectController;
use API\DepartmentController;
use API\RolePermissionController;
use API\AnnouncementController;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });
Route::post('register', [PassportAuthController::class, 'register']);
Route::post('login', [PassportAuthController::class, 'login']);
Route::middleware('auth:api')->group(function () {
    Route::resource('posts', PostController::class);
});

Route::get('announcement_types', "API\AnnouncementController@announcement_type");
Route::get('announcements', "API\AnnouncementController@index");
Route::post('announcement', "API\AnnouncementController@store");

// protected using role based permission in spatie package - laravel
Route::middleware(['auth:api'])->group(function () {
    Route::get('users', [UserController::class,'index']); 
    
    Route::resource('leave', LeaveController::class);
    Route::get('attend_by_user', "API\AttendController@all_attends_user");
    Route::get('totalhours', "API\AttendController@totalhours");
    Route::get('departments', "API\DepartmentController@index");
    Route::get('recentattend', "API\AttendController@recent");

    Route::get('alldepartments', "API\DepartmentController@alldepartments");

    Route::post('attends', "API\AttendController@store");

    
});  
Route::get('permissions', [PermissionController::class,'index']);
Route::post('permissions', [PermissionController::class,'store']);

Route::get('countries', "API\CountryController@index");
Route::get('users', "API\UserManagementController@index");

Route::post('reset-password-request', "API\PasswordResetRequestController@sendPasswordResetEmail");
Route::post('/change-password', "API\ChangePasswordController@passwordResetProcess");

Route::post('departments', "API\DepartmentController@store");
Route::get('departments/{id}', "API\DepartmentController@departmentById");
Route::put('departments/{id}', "API\DepartmentController@update");
Route::delete('departments/{id}', "API\DepartmentController@destroy");
Route::get('designations', "API\DesignationController@index");
Route::post('designations', "API\DesignationController@store");
Route::get('designations/{id}', "API\DesignationController@designationById");
Route::put('designations/{id}', "API\DesignationController@update");
Route::delete('designations/{id}', "API\DesignationController@destroy");
Route::post('applogin', 'API\AttendUserController@login');
Route::get('leavetypes', "API\LeaveTypeController@index");
Route::get('leavestatus', "API\LeaveTypeController@leavestatus");
Route::resource('employees', EmployeesController::class);
Route::post('searchEmployee', "API\EmployeesController@search");
Route::resource('roles', RoleController::class);
Route::get('role-permissions/{id}', 'API\RolePermissionController@edit');
Route::put('role-permissions/{id}', 'API\RolePermissionController@update');
// Route::get('roles/index/{id}', 'API\RoleController@index');
Route::post('roles/update/{id}', 'API\RoleController@updateById');
Route::delete('roles', 'API\RoleController@destroy');


Route::get('attends', "API\AttendController@index");


Route::get('attendexists', "API\AttendController@attendexists");






Route::get('leaves', "API\LeaveManagementController@index");
Route::post('leaves', "API\LeaveManagementController@store");

Route::post('leavesearch', "API\LeaveManagementController@search");

Route::get('attendmanagements', "API\AttendManagementController@index");
Route::post('attendsearch', "API\AttendManagementController@search");
Route::post('attend-report', "API\AttendManagementController@report");




//Forgot Password Routes
Route::post('password/forgot-password','API\ForgotPasswordController@sendResetLinkResponse')->name('passwords.sent');
// Route::get('password/reset/{token}', 'API\ResetPasswordController@ResetResponse')->name('passwords.reset');
Route::post('password/reset', 'API\ResetPasswordController@sendResetResponse')->name('passwords.reset');

