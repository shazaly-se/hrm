<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
Use \Carbon\Carbon;
use App\Models\Attend;
use App\Models\EmployeeInfo;
use App\Models\MonthlyHour;
use Illuminate\Support\Facades\Auth;
use DateTime;
class AttendManagementController extends Controller
{
    public function index(){
        // $to = \Carbon\Carbon::parse('18:00:00');
        // $from = \Carbon\Carbon::parse('10:30:00');
        // $diff_in_hours = $to->diffInMinutes($from);
        // return $diff_in_hours / 60;
        

        $attends=Attend::join("employeeinfos","employeeinfos.id","attends.employee_id")
        ->get(array("attends.*","employeeinfos.fullname","employeeinfos.image"));
        return response()->json([
            "success" => true,
            "attends" => $attends,
            ]);
    }

    public function search(Request $request)
    {
       
        $attends = Attend::join("employeeinfos","employeeinfos.id","attends.employee_id")
        ->where("fullname",'LIKE', "%".$request->searchedName."%")
            ->where(function ($query) use($request){
            if($request->start_date !=null  && $request->end_date!=null ) {$query->whereBetween("attends.created_at",[$request->start_date, $request->end_date]);}
             })
         ->get(array("attends.*","employeeinfos.fullname","employeeinfos.image"));
            return response()->json([
            "success" => true,
            "attends" => $attends,
            ]);
    }

    public function report(Request $request){
       // return $request->all();
        $currentDate = new Carbon($request->start_date);
        
        $currentMonth =  $currentDate->month;
        
    

        $monthlyhours = MonthlyHour::where("month_name",$currentMonth)->first();
       // return $monthlyhours->expected_hours;
        //return $currentMonth;
       // $expected = Carbon::now()->toDateString();


     //   return $expected;
      //  ->whereYear('date', Carbon::now()->month)

        $attends = Attend::join("employeeinfos","employeeinfos.id","attends.employee_id")
        ->where("fullname",'LIKE', "%".$request->searchedName."%")
            ->where(function ($query) use($request){
            if($request->start_date !=null  && $request->end_date!=null ) {$query->whereBetween("attends.date",[$request->start_date, $request->end_date]);}
             })
         ->get(array("attends.*","employeeinfos.fullname","employeeinfos.image"));




         $mins= Attend::join("employeeinfos","employeeinfos.id","attends.employee_id")
         ->where("fullname",'LIKE', "%".$request->searchedName."%")
             ->where(function ($query) use($request){
             if($request->start_date !=null  && $request->end_date!=null ) {$query->whereBetween("attends.date",[$request->start_date, $request->end_date]);}
              })
         ->sum("taken_time_in_min");

             
                $expectedHours = 185;
                $expectedHourlySalary = 4000 / $monthlyhours->expected_hours;
                $hours = round($mins / 60);
            return response()->json([
            "success" => true,
            "attends" => $attends,
            "mins" =>$mins,
            "exacthours"=> $hours,
            "expectedHours" =>  $monthlyhours->expected_hours,
            "expectedHourlySalary"=> round($expectedHourlySalary),
            "exactHourlySalary" => round($expectedHourlySalary) * $hours 
            
            ]);
    }
}
