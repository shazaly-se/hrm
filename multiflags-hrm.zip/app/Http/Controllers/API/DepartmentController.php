<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Department;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
class DepartmentController extends Controller
{

     function __construct()
    {
        $this->middleware('role:super-admin', ['only' => ['index','store']]);

    }
    
    public function index(){
        $departments = Department::orderBy("created_at","desc")->get();
        return response()->json([
            "success" => true,
             'departments'=>$departments
            ]);
    }

    public function alldepartments(){
        $departments = Department::orderBy("created_at","desc")->get(array("departments.id as value","departments.department as label"));
        return response()->json([
            "success" => true,
             'departments'=>$departments
            ]);
    }

    

    public function store(Request $request){
        //return $request->all();
        $department = new Department;
        $department->department = $request->department;
        if($department->save()){
            return response()->json([
                 "success" => true,
                 "message"=>"created successfully",
                // 'department'=>$department
                ]);
        }

    }
    public function departmentById($id){
        $department= Department::find($id);
        if(!$department){
            return response()->json([
                "success" => false,
                "message"=>"department ".$id ." does not exist",
               ]); 
        }
        return response()->json($department);

    }

    public function update($id,Request $request){

   
        $department= Department::find($id);
        if(!$department){
            return response()->json([
                "success" => false,
                "message"=>"department ".$id ." does not exist",
               ]); 
        }

        $department->department = $request->department;
        if($department->update()){
            return response()->json([
                 "success" => true,
                 "message"=>"updated successfully",
                 'department'=>$department
                ]);
        }
    }

    public function destroy($id){
        $department= Department::find($id);
        if(!$department){
            return response()->json([
                "success" => false,
                "message"=>"department ".$id ." does not exist",
               ]); 
        }
        $department->delete();
        return response()->json([
            "success" => true,
            "message"=>"deleted successfully",
            'department'=>$department
           ]);
    }
}
