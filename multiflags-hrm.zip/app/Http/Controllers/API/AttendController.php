<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
Use \Carbon\Carbon;
use App\Models\Attend;
use App\Models\LeaveInfo;
use App\Models\EmployeeInfo;
use App\Models\CompanyInfo;
use Illuminate\Support\Facades\Auth;
use DB;
class AttendController extends Controller
{
    public function recent(){
        $user = auth()->user();
       
        $employee= EmployeeInfo::where("user_id",$user->id)->first();
        
        $recent= Attend::where("employee_id",$employee->id)->take(3)->get(array("attends.check_in","attends.check_out","attends.check_in","total_worked_hours"));
        return response()->json([
            "success" => true,
            "recent" => $recent
            ]);

    }
    public function totalhours(){

        

        $user = auth()->user();
       
        $employee= EmployeeInfo::where("user_id",$user->id)->first();
        
        $hours= Attend::whereMonth('date', Carbon::now()->month)
        ->whereYear('date', Carbon::now()->year)
        ->where("employee_id",$employee->id)
        ->sum("total_worked_hours");

        $leave_days= LeaveInfo::whereYear('created_at', Carbon::now()->year)
        ->where("employee_id",$employee->id)
        ->where("leave_status",2)
        ->sum("number_of_date");
        $remaining= 30 - $leave_days;

           return response()->json([
            "success" => true,
            "total_hours" => round($hours,1),
            "leave_days" => $remaining
            ]);

    //     $total_hours= Attend::select(DB::raw('count(id) as `data`'), DB::raw("DATE_FORMAT(date, '%m-%Y') new_date"),  DB::raw('YEAR(date) year, MONTH(date) month'))
    //     ->groupby('date')
    //     ->where("employee_id",$employee->id)
    //    ->get();
    //    return $total_hours;

        // $attends=Attend::join("employeeinfos","employeeinfos.id","attends.employee_id")
        // ->get(array("attends.*","employeeinfos.fullname"));
        // return response()->json([
        //     "success" => true,
        //     "attends" => $attends,
        //     ]);


    }

    public function index(){
        $attends=Attend::join("employeeinfos","employeeinfos.id","attends.employee_id")
        ->get(array("attends.*","employeeinfos.fullname"));
        return response()->json([
            "success" => true,
            "attends" => $attends,
            ]);
    }

    public function attendexists()
    {
      
        $user = auth()->user();

//         $timeFirst  = strtotime('2011-05-12 18:20:20');
// $timeSecond = strtotime('2011-05-13 18:20:20');
// $differenceInSeconds = $timeSecond - $timeFirst;
// return $differenceInSeconds;
       
        $employee= EmployeeInfo::where("user_id",$user->id)->first();
        $date = Carbon::now();
        $todayDate= $date->toDateString(); 
        $time= $date->toTimeString();
        $emp_record= Attend::where("date",$todayDate)
        ->where("employee_id",$employee->id)
        ->first();
       
      
        $different_time= strtotime($time) - strtotime($emp_record->check_in);
        //return $different_time;
        if($emp_record)
        {

            if($emp_record->check_out !=null || $emp_record->check_out !="")
            {  
                return response()->json([
                "record" => true,
                "check_out" => true,
                "different_time"=>$different_time
                ]);
            }else{
                return response()->json([
                    "record" => true,
                    "check_out" => false,
                    "different_time"=>$different_time
                    ]);
            }

            // if($emp_record->check_in !=null || $emp_record->check_in !="")
            // {  
            //     return response()->json([
            //     "record" => true,
            //     "check_in" => true
            //     ]);
            // }

            // if($emp_record->goBreak !=null || $emp_record->goBreak !="")
            // {  
            //     return response()->json([
            //     "record" => true,
            //     "goBreak" => true
            //     ]);
            // }

            // if($emp_record->resume !=null || $emp_record->resume !="")
            // {  
            //     return response()->json([
            //     "no_record" => true,
            //     "resume" => true
            //     ]);
            // }
       
        }else{
            return response()->json([
                "record" => false,
                "check_out" => false,
                "different_time"=>$different_time
                ]);
        }
    }

    public function store(Request $request){
    // return $request->all();



    //if()
      $user = auth()->user();
      
     //return $user;
      $employee= EmployeeInfo::where("user_id",$user->id)->first();
     // return $employee;
      $company = CompanyInfo::join("employeeinfos","employeeinfos.company_id","companyinfos.id")
      ->where("employeeinfos.id",$employee->id)
      ->where("companyinfos.ip_address",$request->ip_address)
      ->first("companyinfos.*");
      //return $company;

      if($company){

      
        $date = Carbon::now();
        //return $date;

      $todayDate= $date->toDateString(); 
      $time= $date->toTimeString();
   
     $new_attend_employee_record = new Attend;
     
  
      $emp_record= Attend::where("date",$todayDate)
      ->where("employee_id",$employee->id)
      ->first();
      
     
      if($emp_record)
      {
        
          // time management
              
          if($request->goBreak >0){
            $emp_record->goBreak=$time;
            $emp_record->update();
            return response()->json(["success"=>true,"meg"=>"successfully "]);
             }else
                    if($request->resume >0)
                    {
                        $to = \Carbon\Carbon::parse($time);
                        $from = \Carbon\Carbon::parse($emp_record->goBreak);
                        $diff_in_min = $to->diffInMinutes($from);
                        if($diff_in_min >= 60){
                            $emp_record->taken_time_in_min = $diff_in_min;
                        }else{
                            $emp_record->taken_time_in_min = 60;
                         }
                        $emp_record->resume=$time;
                        $emp_record->update();
                        return response()->json(["success"=>true,"meg"=>"successfully "]);
                    }else
                    if($request->checkOut >0){
                        $to = \Carbon\Carbon::parse($time);
                        $from = \Carbon\Carbon::parse($emp_record->check_in);
                        $diff_in_min = $to->diffInMinutes($from);
                        $diff_in_hours = $diff_in_min / 60;
                        $taken_time_in_hours= $emp_record->taken_time_in_min / 60;
                      //  return $taken_time_in_hours;

                        if($emp_record->taken_time_in_min > 60){
                            $total_worked_hours = $diff_in_hours - $taken_time_in_hours;
                            $total_day_salary = 16.66666666666666 * $total_worked_hours;

                            return "total_worked_hours   ".round($total_worked_hours,1) ."\n  total_day_salary  ".round($total_day_salary,1);

                            $emp_record->total_worked_hours = $total_worked_hours;
                            $emp_record->show_worked_hours = $total_worked_hours;
                            $emp_record->day_salary = $total_day_salary;
                            $emp_record->show_day_salary = $total_day_salary;
                            $emp_record->check_out=$time;
                            $emp_record->update();
                            return "diff_in_hours   ".$diff_in_hours ."\n    total_worked_hours   ".$total_worked_hours."\n    taken_time_in_min   ".$emp_record->taken_time_in_min;

                        }else{
                            $total_worked_hours = $diff_in_hours - 1;
                            $total_day_salary= 16.66666666666666 * $total_worked_hours;
                            return "total_worked_hours   ".round($total_worked_hours,1) ."\n  total_day_salary  ".round($total_day_salary,1);
                            $emp_record->total_worked_hours = $total_worked_hours;
                            $emp_record->show_worked_hours = $total_worked_hours;
                            $emp_record->day_salary = $total_day_salary;
                            $emp_record->show_day_salary = $total_day_salary;
                            $emp_record->check_out=$time;
                            $emp_record->update();

                            return "total_hours   ".$diff_in_hours ."\n    taken_time_in_hours   ".$taken_time_in_hours."\n    taken_time_in_min   ".$emp_record->taken_time_in_min;
                        }
                
                       // return "dif hour  ".$diff_in_hours ;

                        $emp_record->check_out=$time;
                        $emp_record->update();
                        return response()->json(["success"=>true,"meg"=>"successfully "]);
                    }

     }
    else
     {

        if($request->checkIn > 0)
        {
            $new_attend_employee_record->employee_id=$employee->id;
            $new_attend_employee_record->date=$date;
            $new_attend_employee_record->check_in=$time;
            $new_attend_employee_record->goBreak="00:00:00";
            $new_attend_employee_record->resume="00:00:00";
            $new_attend_employee_record->check_out="00:00:00";
            $new_attend_employee_record->save();
            return response()->json(["success"=>true,"meg"=>"successfully checkin"]);

        }else
        if($request->goBreak > 0)
        {
           
            $new_attend_employee_record->employee_id=$employee->id;
            $new_attend_employee_record->date=$date;
            $new_attend_employee_record->check_in="00:00:00";
            $new_attend_employee_record->goBreak=$time;
            $new_attend_employee_record->resume="00:00:00";
            
            $new_attend_employee_record->check_out="00:00:00";
            $new_attend_employee_record->save();
            return response()->json(["success"=>true,"meg"=>"successfully go break"]);
        }else
        if($request->resume >0){
            $new_attend_employee_record->employee_id=$employee->id;
            $new_attend_employee_record->date=$date;
            $new_attend_employee_record->check_in="00:00:00";
            $new_attend_employee_record->goBreak="00:00:00";
            $new_attend_employee_record->resume=$time;
            $new_attend_employee_record->check_out="00:00:00";
            $new_attend_employee_record->save();
            return response()->json(["success"=>true,"meg"=>"successfully back"]);
        }
        else
        if($request->checkOut >0){
            $new_attend_employee_record->employee_id=$employee->id;
            $new_attend_employee_record->date=$date;
            $new_attend_employee_record->check_in="00:00:00";
            $new_attend_employee_record->goBreak="00:00:00";
            $new_attend_employee_record->resume="00:00:00";
            $new_attend_employee_record->check_out=$time;
            $new_attend_employee_record->save();
            return response()->json(["success"=>true,"meg"=>"successfully checkout"]);
        }
        
    
    }
    return response()->json(["success"=>true,"meg"=>"successfully "]);
}else{
    return response()->json(["success"=>false,"meg"=>"You are out of range"]);

}
     
        //return $request->all();
    }

    public function all_attends_user(Request $request){
    
        $user = auth()->user();
     
        $employee= EmployeeInfo::where("user_id",$user->id)->first();
       
//return $employee->id;
        $attend_record= Attend::where("employee_id",$employee->id)
        ->get();
        return $attend_record;

         
    }
}
