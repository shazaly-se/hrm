<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
class UserManagementController extends Controller
{
    public function index(){
        $users = User::join("employeeinfos","employeeinfos.user_id","users.id")
        ->get(array("users.id","users.email","employeeinfos.fullname","employeeinfos.image","employeeinfos.employeephone as mobile"));
                // dd($leave);
                return response()->json([
                    "success" => true,
                    "message" => "user List",
                    "users" => $users,
      
                    ]);

    }
}
